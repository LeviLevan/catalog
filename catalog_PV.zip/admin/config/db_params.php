<?php

return array(
			'host' => 'localhost',
			'dbname' => 'books',
			'user' => 'root',
			'password' => '',
);